# 실습 퀴즈
https://www.figma.com/design/xXpfqfQzjqlWVcR1TfUOyN/FOX-QUIZ/duplicate

# 제출 
https://veamcamp.d.pr/b/66cba86c4ffa9200170bd65e

Fox

Lorem ipsum dolor sit amet,
consectetuer adipiscing elit. Aenean
commodo ligula eget dolor. Aenean
massa. Cum sociis natoque
penatibus et magnis dis parturient
montes, nascetur ridiculus mus.
Donec quam felis, ultricies nec
